$(".menu").click(function() {
  2
    $(".menu").toggleClass("active");
  3
    $(".navbar-menu").toggleClass("active");
  4
  });
  